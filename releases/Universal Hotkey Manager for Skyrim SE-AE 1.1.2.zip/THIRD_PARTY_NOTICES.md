# Third-party notices

Universal Hotkey Manager for Skyrim SE-AE 1.1.2 is licensed under GPL-3.0-or-later and built with the following open-source components. The Release ZIP includes the full project `LICENSE` and the component license texts under `ThirdPartyLicenses/`. Complete corresponding source is published at <https://github.com/compilecraftworks/Universal-Hotkey-Manager-for-Skyrim-SE-AE> under the tag matching the binary version.

- CommonLibSSE-NG - MIT License - <https://github.com/alandtse/CommonLibSSE-NG>
- fmt - MIT License - <https://github.com/fmtlib/fmt>
- spdlog - MIT License - <https://github.com/gabime/spdlog>
- Xbyak - 3-clause BSD License - <https://github.com/herumi/xbyak>
- zlib - zlib License - <https://zlib.net/>
- LZ4 - 2-clause BSD License - <https://github.com/lz4/lz4>
- Zydis - MIT License - <https://github.com/zyantific/zydis>
- Zycore - MIT License - <https://github.com/zyantific/zycore-c>
- rapidcsv - BSD-3-Clause License - <https://github.com/d99kris/rapidcsv>
- Dear ImGui - MIT License - <https://github.com/ocornut/imgui>

Dear ImGui and its official Win32/DX11 backends are statically linked into UHM. SKSE64 and Address Library for SKSE Plugins are runtime prerequisites and are not redistributed by UHM. The packaged `mouse.png` and `gamepad.png` are original UHM artwork and are released under GPL-3.0-or-later with the rest of the project.
